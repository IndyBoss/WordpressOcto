# Changelog

### 1.2.0 (release candidate)

* Remove bower package manager (build dependency)

### 1.1.0

* Add option `ignoreDuplicates` to ignore identical markers
* Update all Leaflet dependencies to newest versions
* Update development dependencies

Known issues:
* Norkart/Leaflet-MiniMap#138: Deprecated warning since MiniMap uses L.Mixin.Events

### 1.0.1

* Fix display multiple maps [#1](https://github.com/Xennis/awesome-cluster-map/issues/1)
* Update all Leaflet dependencies to newest versions
* Update documentation
* Remove unused code

### 1.0.0

* Initial implementation


