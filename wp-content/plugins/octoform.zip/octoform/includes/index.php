<?php  //Silence is golden.
